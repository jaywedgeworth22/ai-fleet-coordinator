---
name: apple-notes
description: Write owner-facing Apple Notes in the iCloud Coding folder — plans, designs, reviews, handoffs, rollouts, living Completion notes. Use whenever Monet produces something the owner needs to read, not only when they say "Notes." Title [APP, Monet] … with a refreshed timestamp.
---

# Apple Notes (MONET)

Mac only.  Cloud sessions: skip Notes, say so, leave the handoff in the PR.

Notes.app does not render raw Markdown.  The helper converts MD → HTML.  Pass `--html` only when you already have Notes-safe HTML.

## Helper

```bash
/Users/jay/apps/apple-notes-coding.sh "Title" "plain body"
/Users/jay/apps/apple-notes-coding.sh "Title" --html /path/to/body.html
/Users/jay/apps/apple-notes-coding.sh --update "Title" "body"
/Users/jay/apps/apple-notes-coding.sh --update "Title" --html /path/to/body.html
/Users/jay/apps/apple-notes-coding.sh --pin-only "Exact Title"
/Users/jay/apps/apple-notes-coding.sh --unpin-only "Exact Title"
```

Also: `--notify` / `--pushover`, `--needs-owner` / `--action-required`, `--summary "one sentence"`, `--pr "18"`.

Default is headless pin via the `Pin Coding Note` shortcut (no focus steal).  Do not `APPLE_NOTES_ACTIVATE=1` unless the owner is sitting at the Mac.

## Title

```
[APP, Monet] short topic
```

- Acronyms first, then `Monet` (Title Case, not `MONET`).
- Multi-app: `[ST, CT, Monet] …` (impact order).
- No date in the title.  No word "session".  Do not repeat the title as an H1 in the body.

| Acronym | App |
|---------|-----|
| UM | Usage-Monitor |
| ST | Socratic.Trade |
| CT | Congress.Trade |
| CTS | congress-trading-shared |
| DD | DealDex |
| PS | Personal-Site |
| FLEET | cross-app / infra / policy |

## Second body row

The helper injects/refreshes:

```
Sun, Aug 9, 3:52pm · PR #18
```

Local Mac time, no leading zeros, lowercase am/pm.  Refresh on every `--update`.

Then: type line (`Completion` / `Plan` / `Review` / `Design` / `Handoff` / `Rollout` / `Incident` / `Fleet change` / `Work log`), then content.

Order: `Needs owner` first when applicable, then Problem → What was done → Decisions → Next steps.

Sentence gaps: markdown/plain bodies use two ASCII spaces (the helper turns them into `&nbsp; `).  **`--html` bodies are HTML** — Notes.app collapses ASCII doubles, so write `Sentence one.&nbsp; Sentence two.`  The helper also converts leftover `.  ` / `!  ` / `?  ` in HTML (not inside `<code>` / `<pre>`).

## Layout (owner 2026-08-21 — binding)

Notes.app collapses adjacent blocks.  A wall of text with no air is a bug.  The owner reads these on iPhone.

Prefer `--html` for anything longer than a few lines.  In that HTML:

- `<h2>` never `<h1>` (the helper already wraps the title as `h1`)
- After the type line: `<div><br></div>`
- After every heading: `<div><br></div>`
- After every paragraph: `<div><br></div>`
- Between every bullet in the same list: `<div><br></div>`
- After a list, before the next heading: `<div><br></div>`
- Between sentences: `end.&nbsp; Start` — never two ASCII spaces in HTML (they collapse)

Do not pass a packed markdown blob.  If you use the plain-body MD path, put a blank line between every section and every bullet — the helper turns those blanks (and consecutive list items) into spacers.  `--html` with explicit spacers is still the owner-readable path.

## When

Do Notes: plans, design docs, reviews, handoffs, rollouts, **Completion / work-complete** for anything the owner might ask about.

Skip: pure `#agent-sync` chatter, effort-board row edits, routine commit messages, peer-only PR nits.

Open a living work note when substantial work starts.  Always Completion at the end.  Update in place; unpin stale Completion notes when the lane closes (`--unpin-only`).

Background-jobs inventory note is `⭐️ Background Jobs Master List` — refresh that title exactly when `MAC-LOCAL-PROCESSES.md` changes.

## Canon

- `/Users/jay/apps/AGENT-SYNC.md` § Apple Notes
- Skills: `closeout`, `owner-copy`
